# VoiceX Gaming v2 — Live Voice Changer (Android, tanpa root)

Voice changer live dengan suara natural (bukan suara robot/AI): pitch dan karakter
suara (formant) diatur terpisah memakai pitch-tracked PSOLA, jadi intonasi dan ritme
bicara aslimu tetap terdengar manusiawi.

## Fitur
- Live: mic -> efek -> headset/speaker, latency algoritma ~50-65 ms.
- Foreground service: tetap jalan saat kamu pindah ke game/aplikasi lain.
- 10 template bawaan (Cowok Dewasa/Berat/Muda, Cewek Natural/Lembut/Imut, Anak Kecil,
  Radio Walkie, Monster, Asli) + simpan template buatan sendiri (tahan lama untuk hapus).
- Semua bisa diatur live: Pitch, Karakter (besar/kecil), Hangat/bass, Jelas, Udara,
  Napas halus, Radio, Noise gate, Penyeimbang volume, Gema, Gain mic, Volume.

## Batasan penting
Android biasa **tidak bisa** mengganti mic untuk game/aplikasi lain tanpa root.
Suara olahan keluar lewat headset/speaker. Cara pakai yang realistis:
- Sambungkan output HP ke PC/HP lain lewat kabel audio (mic-in) lalu pakai Discord dll.
- Atau pakai untuk latihan/monitor suara dan template.
Pakai headset agar tidak berdengung (feedback).

## Build APK di GitHub (dari HP)
1. Upload semua file ke repo GitHub (struktur folder tetap).
2. Tab Actions -> **Build VoiceX APK** -> Run workflow.
3. Download artifact `VoiceX-Gaming-debug-apk`, ekstrak, install `app-debug.apk`.
4. Izinkan mikrofon dan notifikasi saat diminta.

## Struktur kode
- `PitchFormantShifter.kt` — pitch + formant natural (PSOLA).
- `VoiceFx.kt` — gate, EQ, napas, radio, compressor, reverb, limiter.
- `VoiceParams.kt` — parameter, template, penyimpanan template.
- `VoiceEngine.kt` / `VoiceService.kt` — audio live + foreground service.
- `MainActivity.kt` — UI.

Catatan: kode Kotlin belum sempat di-compile/diuji di perangkat saat dibuat; algoritma
DSP sudah diuji lewat prototipe Python. Kalau build error, kirim lognya.
