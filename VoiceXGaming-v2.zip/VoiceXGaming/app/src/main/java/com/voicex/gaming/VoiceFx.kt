package com.voicex.gaming

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

private class Biquad {
    private var b0 = 1.0; private var b1 = 0.0; private var b2 = 0.0
    private var a1 = 0.0; private var a2 = 0.0
    private var x1 = 0.0; private var x2 = 0.0; private var y1 = 0.0; private var y2 = 0.0
    var active = false

    private fun set(nb0: Double, nb1: Double, nb2: Double, na0: Double, na1: Double, na2: Double) {
        b0 = nb0 / na0; b1 = nb1 / na0; b2 = nb2 / na0; a1 = na1 / na0; a2 = na2 / na0
    }

    fun peaking(sr: Int, f: Double, db: Double, q: Double) {
        val a = 10.0.pow(db / 40); val w = 2 * PI * f / sr; val al = sin(w) / (2 * q); val c = cos(w)
        set(1 + al * a, -2 * c, 1 - al * a, 1 + al / a, -2 * c, 1 - al / a)
    }

    fun lowShelf(sr: Int, f: Double, db: Double) {
        val a = 10.0.pow(db / 40); val w = 2 * PI * f / sr; val c = cos(w)
        val al = sin(w) / 2 * sqrt(2.0); val t = 2 * sqrt(a) * al
        set(a * ((a + 1) - (a - 1) * c + t), 2 * a * ((a - 1) - (a + 1) * c), a * ((a + 1) - (a - 1) * c - t),
            (a + 1) + (a - 1) * c + t, -2 * ((a - 1) + (a + 1) * c), (a + 1) + (a - 1) * c - t)
    }

    fun highShelf(sr: Int, f: Double, db: Double) {
        val a = 10.0.pow(db / 40); val w = 2 * PI * f / sr; val c = cos(w)
        val al = sin(w) / 2 * sqrt(2.0); val t = 2 * sqrt(a) * al
        set(a * ((a + 1) + (a - 1) * c + t), -2 * a * ((a - 1) + (a + 1) * c), a * ((a + 1) + (a - 1) * c - t),
            (a + 1) - (a - 1) * c + t, 2 * ((a - 1) - (a + 1) * c), (a + 1) - (a - 1) * c - t)
    }

    fun highPass(sr: Int, f: Double, q: Double = 0.707) {
        val w = 2 * PI * f / sr; val c = cos(w); val al = sin(w) / (2 * q)
        set((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al)
    }

    fun lowPass(sr: Int, f: Double, q: Double = 0.707) {
        val w = 2 * PI * f / sr; val c = cos(w); val al = sin(w) / (2 * q)
        set((1 - c) / 2, 1 - c, (1 - c) / 2, 1 + al, -2 * c, 1 - al)
    }

    fun tick(x: Double): Double {
        val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        x2 = x1; x1 = x; y2 = y1; y1 = y
        return y
    }
}

/** Rantai efek suara lengkap (dipanggil dari thread audio). */
class VoiceFx(private val sr: Int) {
    private val shifter = PitchFormantShifter(sr)

    private val hp = Biquad()
    private val low = Biquad()
    private val mid = Biquad()
    private val high = Biquad()
    private val radioHp = Biquad()
    private val radioLp = Biquad()

    @Volatile private var pending: VoiceParams? = VoiceParams()
    private var p = VoiceParams()
    private var shiftComp = 1.0
    @Volatile var peak = 0f
        private set

    // gate / dynamics / breath state
    private var gateGain = 0.0
    private var gateEnv = 0.0
    private var compEnv = 0.0
    private var breathEnv = 0.0
    private var noiseHp = 0.0
    private var noisePrev = 0.0
    private var seed = 22222

    // reverb
    private val scale = sr / 44100.0
    private val combLens = intArrayOf(1116, 1188, 1277, 1356).map { (it * scale).toInt() }
    private val combBuf = combLens.map { FloatArray(it) }
    private val combIdx = IntArray(4)
    private val combLp = FloatArray(4)
    private val apLens = intArrayOf(556, 441).map { (it * scale).toInt() }
    private val apBuf = apLens.map { FloatArray(it) }
    private val apIdx = IntArray(2)

    fun setParams(np: VoiceParams) { pending = np }

    private fun applyParams(np: VoiceParams) {
        p = np
        shifter.pitch = 2.0.pow(np.pitchSt / 12.0).toFloat()
        shifter.formant = 2.0.pow(np.formantSt / 12.0).toFloat()
        shiftComp = 10.0.pow(min(abs(np.pitchSt), 12f) * 0.3 / 20.0)
        hp.highPass(sr, 80.0)
        low.lowShelf(sr, 200.0, np.warmth.toDouble())
        mid.peaking(sr, 3000.0, np.presence.toDouble(), 0.9)
        high.highShelf(sr, min(8000.0, sr * 0.4), np.air.toDouble())
        val r = np.radio / 100.0
        radioHp.highPass(sr, 100.0 + r * 500.0)
        radioLp.lowPass(sr, 12000.0 - r * 9000.0)
    }

    private fun noise(): Double {
        seed = seed * 1664525 + 1013904223
        return (seed shr 8) / 8388608.0
    }

    private fun reverbTick(inp: Float): Float {
        var sum = 0f
        for (c in 0 until 4) {
            val buf = combBuf[c]; val i = combIdx[c]
            val out = buf[i]
            combLp[c] = out * 0.7f + combLp[c] * 0.3f
            buf[i] = inp + combLp[c] * 0.78f
            combIdx[c] = if (i + 1 >= buf.size) 0 else i + 1
            sum += out
        }
        var s = sum * 0.25f
        for (a in 0 until 2) {
            val buf = apBuf[a]; val i = apIdx[a]
            val d = buf[i]
            val o = -s + d
            buf[i] = s + d * 0.5f
            apIdx[a] = if (i + 1 >= buf.size) 0 else i + 1
            s = o
        }
        return s
    }

    fun reset() { shifter.reset() }

    /** Proses [count] sampel float (-1..1) langsung di [buf]. */
    fun process(buf: FloatArray, count: Int) {
        pending?.let { applyParams(it); pending = null }
        val gain = 10.0.pow(p.micGain / 20.0)
        val gateThr = if (p.gate <= 0f) 0.0 else 0.002 + (p.gate / 100.0) * 0.03
        val aRel = exp(-1.0 / (0.12 * sr))
        val aGate = exp(-1.0 / (0.01 * sr))
        val ratio = 1.0 + (p.compress / 100.0) * 5.0
        val compThr = 0.18
        val aAtt = exp(-1.0 / (0.005 * sr))
        val aCrel = exp(-1.0 / (0.12 * sr))
        val makeup = 1.0 + (p.compress / 100.0) * 0.9
        val wet = (p.reverb / 100.0) * 0.45
        val breathAmt = (p.breath / 100.0) * 0.12
        val vol = p.volume / 100.0

        // 1) gain + gate (sebelum pitch agar noise tidak ikut digeser)
        for (i in 0 until count) {
            var s = buf[i] * gain
            val a = abs(s)
            gateEnv = if (a > gateEnv) a else gateEnv * aRel + a * (1 - aRel)
            val target = if (gateThr == 0.0 || gateEnv > gateThr) 1.0 else 0.0
            gateGain = gateGain * aGate + target * (1 - aGate)
            buf[i] = (s * gateGain).toFloat()
        }

        // 2) pitch + formant
        shifter.process(buf, count)

        var pk = 0f
        for (i in 0 until count) {
            var s = buf[i].toDouble() * shiftComp

            // 3) EQ + radio
            s = hp.tick(s)
            s = low.tick(s)
            s = mid.tick(s)
            s = high.tick(s)
            if (p.radio > 0f) { s = radioHp.tick(s); s = radioLp.tick(s) }

            // 4) napas halus mengikuti volume suara
            val a = abs(s)
            breathEnv = if (a > breathEnv) breathEnv + (a - breathEnv) * 0.05 else breathEnv * aRel + a * (1 - aRel)
            if (breathAmt > 0) {
                val n = noise()
                noiseHp = n - noisePrev; noisePrev = n
                s += noiseHp * 0.5 * breathEnv * breathAmt * 4.0
            }

            // 5) compressor
            val lv = abs(s)
            compEnv = if (lv > compEnv) compEnv * aAtt + lv * (1 - aAtt) else compEnv * aCrel + lv * (1 - aCrel)
            if (compEnv > compThr) {
                val g = (compThr + (compEnv - compThr) / ratio) / compEnv
                s *= g
            }
            s *= makeup

            // 6) reverb
            if (wet > 0) s += reverbTick(s.toFloat()) * wet

            // 7) volume + limiter lembut
            s = tanh(s * vol * 1.1) * 0.95
            val out = s.toFloat()
            buf[i] = out
            if (abs(out) > pk) pk = abs(out)
        }
        peak = max(pk, peak * 0.9f)
    }
}
