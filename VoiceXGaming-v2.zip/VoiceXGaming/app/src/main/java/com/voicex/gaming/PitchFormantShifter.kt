package com.voicex.gaming

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Streaming PSOLA-style shifter. Pitch (f0) and formants (vocal tract size) are
 * controlled independently, so the voice keeps its natural rhythm and intonation
 * and does not get the "chipmunk" or robotic sound of plain resampling.
 *
 * Port of the validated Python prototype. Output has ~45-65 ms algorithmic latency.
 */
class PitchFormantShifter(private val sr: Int) {
    @Volatile var pitch = 1.0f
    @Volatile var formant = 1.0f

    private val minT = sr / 400
    private val maxT = sr / 85
    private val defT = (sr * 0.007).toInt()
    private val ring = 1 shl 16
    private val mask = ring - 1
    private val x = FloatArray(ring)
    private val acc = FloatArray(ring)
    private val wacc = FloatArray(ring)
    private var n = 0L

    private var curT = defT.toDouble()
    private var curV = 0.0
    private var nextP = 0L
    private val pw = (sr * 0.032).toInt()
    private val pHop = (sr * 0.005).toInt()

    private val markPos = ArrayList<Double>()
    private val markT = ArrayList<Double>()
    private val markV = ArrayList<Double>()
    private var mi = 0
    private var hasMark = false

    private var tm = 0.0
    private var tmInit = false
    private var emit = 0L
    private val lat = (sr * 0.046).toInt()

    private fun xi(i: Long): Float = x[(i and mask.toLong()).toInt()]

    private fun interp(pos: Double): Float {
        val i = floor(pos).toLong()
        val fr = (pos - i).toFloat()
        return xi(i) * (1f - fr) + xi(i + 1) * fr
    }

    fun reset() {
        x.fill(0f); acc.fill(0f); wacc.fill(0f)
        n = 0; nextP = 0; curT = defT.toDouble(); curV = 0.0
        markPos.clear(); markT.clear(); markV.clear(); mi = 0; hasMark = false
        tmInit = false; emit = 0
    }

    private fun analysePitch() {
        val st = 4
        val len = pw / st
        val seg = FloatArray(len)
        var e0 = 1e-9
        for (i in 0 until len) {
            val v = xi(nextP + i.toLong() * st)
            seg[i] = v; e0 += v * v
        }
        val lo = minT / st
        val hi = maxT / st
        val m = len - hi
        nextP += pHop
        if (m < 8) return
        var ea = 1e-9
        for (i in 0 until m) ea += seg[i] * seg[i]
        val cs = DoubleArray(hi - lo + 1)
        var mx = -1.0
        for (l in lo..hi) {
            var num = 0.0
            var eb = 1e-9
            for (i in 0 until m) { val b = seg[l + i]; num += seg[i] * b; eb += b * b }
            val c = num / sqrt(ea * eb)
            cs[l - lo] = c
            if (c > mx) mx = c
        }
        var pick = 0
        for (i in 1 until cs.size) if (cs[i] > cs[pick]) pick = i
        for (i in 1 until cs.size - 1) {
            if (cs[i] >= 0.85 * mx && cs[i] >= cs[i - 1] && cs[i] >= cs[i + 1]) { pick = i; break }
        }
        var lag = ((pick + lo) * st).toDouble()
        if (pick > 0 && pick < cs.size - 1) {
            val d = cs[pick - 1] - 2 * cs[pick] + cs[pick + 1]
            if (abs(d) > 1e-9) lag += st * 0.5 * (cs[pick - 1] - cs[pick + 1]) / d
        }
        val rms = sqrt(e0 / len)
        if (cs[pick] > 0.55 && rms > 0.003) {
            curT = 0.6 * curT + 0.4 * min(max(lag, minT.toDouble()), maxT.toDouble())
            curV = min(1.0, curV + 0.5)
        } else {
            curV = max(0.0, curV - 0.35)
        }
    }

    private fun addMarks() {
        while (true) {
            val t = if (curV > 0.4) curT else defT.toDouble()
            if (!hasMark) {
                if (n < 3L * maxT) return
                markPos.add((n - 3L * maxT).toDouble()); markT.add(t); markV.add(curV)
                hasMark = true
                continue
            }
            val lp = markPos[markPos.size - 1]
            val pred = lp + t
            val r = (0.25 * t).toInt()
            val half = (0.5 * t).toInt()
            if (n < pred + r + half + 2) return
            var best = pred
            if (curV > 0.4) {
                var bs = -1e18
                var sh = -r
                while (sh <= r) {
                    var num = 0.0; var e1 = 1e-9; var e2 = 1e-9
                    var i = -half
                    while (i < half) {
                        val u = interp(lp + i).toDouble()
                        val v = interp(pred + sh + i).toDouble()
                        num += u * v; e1 += u * u; e2 += v * v
                        i += 3
                    }
                    val sc = num / sqrt(e1 * e2)
                    if (sc > bs) { bs = sc; best = pred + sh }
                    sh += 2
                }
            }
            markPos.add(best); markT.add(t); markV.add(curV)
        }
    }

    private fun synth() {
        if (!tmInit) {
            if (markPos.isEmpty()) return
            tm = markPos[0]; tmInit = true
            emit = floor(tm).toLong() - lat
        }
        val p = pitch.toDouble()
        val f = formant.toDouble()
        while (true) {
            val c = tm
            if (markPos[markPos.size - 1] < c + maxT * 0.6) break
            while (mi + 1 < markPos.size && abs(markPos[mi + 1] - c) <= abs(markPos[mi] - c)) mi++
            val a = markPos[mi]; val tg = markT[mi]; val v = markV[mi]
            val pe = 1.0 + (p - 1.0) * min(1.0, v)
            val lin = 2.0 * tg * max(1.0, f / pe)
            if (a + lin / 2 + 2 > n) break
            val ho = lin / f / 2.0
            val i0 = Math.ceil(c - ho).toLong()
            val i1 = floor(c + ho).toLong()
            var i = i0
            while (i <= i1) {
                val u = i - c
                val w = (0.5 + 0.5 * cos(Math.PI * u / ho)).toFloat()
                val idx = (i and mask.toLong()).toInt()
                acc[idx] += w * interp(a + u * f)
                wacc[idx] += w
                i++
            }
            tm = c + tg / pe
            if (mi > 8) {
                val cut = mi - 4
                markPos.subList(0, cut).clear(); markT.subList(0, cut).clear(); markV.subList(0, cut).clear()
                mi = 4
            }
        }
    }

    /** Process [count] samples in place of [buf] (mono float, -1..1). */
    fun process(buf: FloatArray, count: Int) {
        for (i in 0 until count) x[((n + i) and mask.toLong()).toInt()] = buf[i]
        n += count
        while (nextP + pw <= n) analysePitch()
        addMarks()
        synth()
        if (!tmInit) { for (i in 0 until count) buf[i] = 0f; return }
        val nextHalf = curT * max(1.0 / formant, 1.0 / max(0.3, pitch.toDouble())) * 1.1 + 2
        val safe = (tm - nextHalf).toLong()
        for (i in 0 until count) {
            val k = emit
            val idx = (k and mask.toLong()).toInt()
            if (k < safe) {
                val w = wacc[idx]
                buf[i] = if (w > 1e-6f) acc[idx] / max(w, 0.5f) else 0f
                acc[idx] = 0f; wacc[idx] = 0f
            } else buf[i] = 0f
            emit++
        }
    }
}
