package com.voicex.gaming

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 12, 24)
    private val cardColor = Color.rgb(24, 24, 44)
    private val accent = Color.rgb(0, 200, 150)
    private val ui = Handler(Looper.getMainLooper())
    private val reqCode = 77

    private var params = VoiceParams()
    private val refreshers = ArrayList<() -> Unit>()
    private lateinit var status: TextView
    private lateinit var startButton: Button
    private lateinit var meter: ProgressBar
    private lateinit var chips: LinearLayout
    private var activePreset = "Asli"

    private val ticker = object : Runnable {
        override fun run() {
            val on = VoiceEngine.running
            startButton.text = if (on) "STOP" else "MULAI LIVE"
            startButton.background = round(if (on) Color.rgb(220, 60, 70) else accent, 14)
            status.text = if (on) "● LIVE — template: $activePreset" else "Status: OFF"
            meter.progress = if (on) (VoiceEngine.peak() * 100).toInt() else 0
            ui.postDelayed(this, 60)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        params = Presets.loadLast(this)
        if (params != VoiceParams()) activePreset = "Custom"
        buildUi()
        pushParams()
    }

    override fun onResume() { super.onResume(); ui.post(ticker) }
    override fun onPause() { ui.removeCallbacks(ticker); Presets.saveLast(this, params); super.onPause() }

    private fun pushParams() { VoiceEngine.setParams(params); refreshers.forEach { it() } }

    private fun text(t: String, size: Float = 15f, color: Int = Color.WHITE) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); setPadding(0, dp(4), 0, dp(4))
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(32))
            setBackgroundColor(bg)
        }
        root.addView(text("VOICEX GAMING", 26f))
        root.addView(text("Live voice changer • suara natural • semua bisa diatur", 12f, Color.LTGRAY))
        status = text("Status: OFF", 15f, accent)
        root.addView(status)

        meter = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        root.addView(meter, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8)))

        startButton = Button(this).apply {
            setTextColor(Color.BLACK); textSize = 17f
            setOnClickListener { if (VoiceEngine.running) stopLive() else startLive() }
        }
        root.addView(startButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply {
            topMargin = dp(12); bottomMargin = dp(8)
        })
        root.addView(text("Pakai headset supaya tidak berdengung (feedback).", 12f, Color.LTGRAY))

        root.addView(text("TEMPLATE", 13f, accent))
        chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) })
        rebuildChips()

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(smallButton("Simpan template") { saveDialog() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { rightMargin = dp(6) })
        row.addView(smallButton("Reset") { applyPreset(Presets.builtin[0]) }, LinearLayout.LayoutParams(0, dp(46), 1f))
        root.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        root.addView(text("Tahan lama template buatanmu untuk menghapus.", 11f, Color.GRAY))

        section(root, "SUARA UTAMA")
        slider(root, "Pitch (nada)", -12f, 12f, " st", { it.pitchSt }, { p, v -> p.copy(pitchSt = v) })
        slider(root, "Karakter (besar ↔ kecil)", -8f, 8f, " st", { it.formantSt }, { p, v -> p.copy(formantSt = v) })
        section(root, "WARNA SUARA")
        slider(root, "Hangat / bass", -8f, 8f, " dB", { it.warmth }, { p, v -> p.copy(warmth = v) })
        slider(root, "Jelas / presence", -6f, 8f, " dB", { it.presence }, { p, v -> p.copy(presence = v) })
        slider(root, "Udara / cerah", -6f, 8f, " dB", { it.air }, { p, v -> p.copy(air = v) })
        slider(root, "Napas halus", 0f, 100f, "%", { it.breath }, { p, v -> p.copy(breath = v) })
        slider(root, "Efek radio / walkie", 0f, 100f, "%", { it.radio }, { p, v -> p.copy(radio = v) })
        section(root, "KUALITAS")
        slider(root, "Penahan noise (gate)", 0f, 100f, "%", { it.gate }, { p, v -> p.copy(gate = v) })
        slider(root, "Penyeimbang volume", 0f, 100f, "%", { it.compress }, { p, v -> p.copy(compress = v) })
        slider(root, "Gema ruangan", 0f, 100f, "%", { it.reverb }, { p, v -> p.copy(reverb = v) })
        slider(root, "Gain mic", -12f, 12f, " dB", { it.micGain }, { p, v -> p.copy(micGain = v) })
        slider(root, "Volume keluar", 0f, 150f, "%", { it.volume }, { p, v -> p.copy(volume = v) })

        root.addView(text(
            "Catatan: Android biasa tidak bisa mengganti mic game lain tanpa root. " +
                "Suara olahan keluar ke headset/speaker, atau sambungkan kabel audio ke PC/HP lain.",
            12f, Color.GRAY
        ))
        setContentView(ScrollView(this).apply { setBackgroundColor(bg); addView(root) })
    }

    private fun section(root: LinearLayout, title: String) {
        root.addView(text(title, 13f, accent).apply { setPadding(0, dp(18), 0, dp(2)) })
    }

    private fun smallButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; setAllCaps(false); setTextColor(Color.WHITE); textSize = 13f
        background = round(Color.rgb(50, 50, 80), 12)
        setOnClickListener { onClick() }
    }

    private fun slider(
        root: LinearLayout, label: String, min: Float, max: Float, unit: String,
        get: (VoiceParams) -> Float, set: (VoiceParams, Float) -> VoiceParams
    ) {
        val title = text("", 14f)
        val bar = SeekBar(this).apply { this.max = 1000 }
        fun show() {
            val v = get(params)
            title.text = String.format(Locale.US, "%s: %.1f%s", label, v, unit)
            bar.progress = (((v - min) / (max - min)) * 1000f).toInt().coerceIn(0, 1000)
        }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                var v = min + (max - min) * progress / 1000f
                v = Math.round(v * 2f) / 2f   // langkah 0.5
                params = set(params, v)
                title.text = String.format(Locale.US, "%s: %.1f%s", label, v, unit)
                VoiceEngine.setParams(params)
                activePreset = "Custom"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        refreshers.add { show() }
        root.addView(card(title, bar))
    }

    private fun card(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(12), dp(8), dp(12), dp(8))
        background = round(cardColor, 12)
        views.forEach { addView(it) }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) }
    }

    private fun rebuildChips() {
        chips.removeAllViews()
        val all = Presets.builtin + Presets.loadCustom(this)
        for (pr in all) {
            val b = Button(this).apply {
                text = if (pr.custom) "★ ${pr.name}" else pr.name
                setAllCaps(false); textSize = 13f; setTextColor(Color.WHITE)
                background = round(if (pr.name == activePreset) Color.rgb(0, 120, 95) else Color.rgb(50, 50, 80), 18)
                setOnClickListener { applyPreset(pr) }
                if (pr.custom) setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Hapus \"${pr.name}\"?")
                        .setPositiveButton("Hapus") { _, _ -> Presets.deleteCustom(this@MainActivity, pr.name); rebuildChips() }
                        .setNegativeButton("Batal", null).show()
                    true
                }
            }
            chips.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)).apply { rightMargin = dp(6) })
        }
    }

    private fun applyPreset(pr: Preset) {
        params = pr.params
        activePreset = pr.name
        pushParams()
        rebuildChips()
    }

    private fun saveDialog() {
        val input = EditText(this).apply {
            hint = "Nama template"; inputType = InputType.TYPE_CLASS_TEXT
        }
        AlertDialog.Builder(this)
            .setTitle("Simpan template suara")
            .setView(input)
            .setPositiveButton("Simpan") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    Presets.saveCustom(this, name, params)
                    activePreset = name.take(24)
                    rebuildChips()
                    Toast.makeText(this, "Template tersimpan", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun startLive() {
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isEmpty()) launchService() else requestPermissions(need.toTypedArray(), reqCode)
    }

    private fun launchService() {
        VoiceEngine.setParams(params)
        startForegroundService(Intent(this, VoiceService::class.java))
    }

    private fun stopLive() {
        startService(Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_STOP))
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != reqCode) return
        val micIdx = permissions.indexOf(Manifest.permission.RECORD_AUDIO)
        val micDenied = micIdx >= 0 && grantResults.getOrNull(micIdx) != PackageManager.PERMISSION_GRANTED
        val micOk = !micDenied && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (micOk) launchService() else Toast.makeText(this, "Izin mikrofon diperlukan", Toast.LENGTH_LONG).show()
    }
}
