package com.voicex.gaming

import android.content.Context

/** Semua pengaturan suara. Semua bisa diubah live dari UI. */
data class VoiceParams(
    val pitchSt: Float = 0f,      // semiton, -12..+12
    val formantSt: Float = 0f,    // ukuran "rongga suara" (semiton), -8..+8
    val warmth: Float = 0f,       // dB low shelf 200 Hz, -8..+8
    val presence: Float = 0f,     // dB peak 3 kHz, -6..+8
    val air: Float = 0f,          // dB high shelf 8 kHz, -6..+8
    val breath: Float = 0f,       // 0..100 napas halus
    val radio: Float = 0f,        // 0..100 efek radio/walkie
    val gate: Float = 15f,        // 0..100 penahan noise
    val compress: Float = 30f,    // 0..100 penyeimbang volume
    val reverb: Float = 0f,       // 0..100 gema ruangan
    val micGain: Float = 0f,      // dB, -12..+12
    val volume: Float = 100f      // 0..150 %
) {
    fun serialize(): String =
        "$pitchSt;$formantSt;$warmth;$presence;$air;$breath;$radio;$gate;$compress;$reverb;$micGain;$volume"

    companion object {
        fun parse(s: String): VoiceParams? = try {
            val v = s.split(";").map { it.toFloat() }
            VoiceParams(v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8], v[9], v[10], v[11])
        } catch (e: Exception) { null }
    }
}

data class Preset(val name: String, val params: VoiceParams, val custom: Boolean = false)

object Presets {
    /** Template bawaan: semua dibuat natural (pitch & formant bergerak bersama secara wajar). */
    val builtin = listOf(
        Preset("Asli", VoiceParams()),
        Preset("Cowok Dewasa", VoiceParams(pitchSt = -3.5f, formantSt = -2.0f, warmth = 2f, presence = 1f, compress = 40f)),
        Preset("Cowok Berat", VoiceParams(pitchSt = -6f, formantSt = -3.5f, warmth = 3.5f, air = -1f, compress = 45f)),
        Preset("Cowok Muda", VoiceParams(pitchSt = -1.5f, formantSt = -0.8f, presence = 1.5f, air = 1f, compress = 35f)),
        Preset("Cewek Natural", VoiceParams(pitchSt = 5f, formantSt = 2.2f, warmth = -1f, presence = 1.5f, air = 2f, breath = 12f, compress = 35f)),
        Preset("Cewek Lembut", VoiceParams(pitchSt = 6.5f, formantSt = 2.8f, warmth = 1f, presence = 0.5f, air = 1.5f, breath = 25f, compress = 40f, reverb = 6f)),
        Preset("Cewek Imut", VoiceParams(pitchSt = 8f, formantSt = 3.8f, presence = 2f, air = 3f, breath = 10f, compress = 40f)),
        Preset("Anak Kecil", VoiceParams(pitchSt = 10f, formantSt = 5f, presence = 1f, air = 2f, compress = 40f)),
        Preset("Radio Walkie", VoiceParams(radio = 85f, presence = 3f, compress = 70f, gate = 25f)),
        Preset("Monster", VoiceParams(pitchSt = -10f, formantSt = -6f, warmth = 4f, reverb = 12f, compress = 50f))
    )

    private const val FILE = "voicex_presets"

    fun loadCustom(ctx: Context): List<Preset> {
        val sp = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val names = sp.getString("names", "")!!.split("\n").filter { it.isNotBlank() }
        return names.mapNotNull { nm ->
            sp.getString("p_$nm", null)?.let { VoiceParams.parse(it) }?.let { Preset(nm, it, true) }
        }
    }

    fun saveCustom(ctx: Context, name: String, p: VoiceParams) {
        val clean = name.trim().replace("\n", " ").take(24)
        if (clean.isEmpty()) return
        val sp = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val names = sp.getString("names", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
        if (!names.contains(clean)) names.add(clean)
        sp.edit().putString("names", names.joinToString("\n")).putString("p_$clean", p.serialize()).apply()
    }

    fun deleteCustom(ctx: Context, name: String) {
        val sp = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val names = sp.getString("names", "")!!.split("\n").filter { it.isNotBlank() && it != name }
        sp.edit().putString("names", names.joinToString("\n")).remove("p_$name").apply()
    }

    fun saveLast(ctx: Context, p: VoiceParams) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("last", p.serialize()).apply()
    }

    fun loadLast(ctx: Context): VoiceParams =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("last", null)
            ?.let { VoiceParams.parse(it) } ?: VoiceParams()
}
