package com.voicex.gaming

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Process
import kotlin.math.max

/** Mesin audio live: mic -> VoiceFx -> speaker/headset. Dipakai bersama oleh Activity & Service. */
object VoiceEngine {
    @Volatile var running = false
        private set

    private var fx: VoiceFx? = null
    private var params = VoiceParams()
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private var worker: Thread? = null

    fun setParams(p: VoiceParams) { params = p; fx?.setParams(p) }
    fun peak(): Float = fx?.peak ?: 0f

    /** Mengembalikan null jika sukses, atau pesan error. */
    @Synchronized
    fun start(): String? {
        if (running) return null
        var lastError = "Mikrofon tidak bisa dibuka"
        for (rate in intArrayOf(48000, 44100)) {
            var rec: AudioRecord? = null
            var trk: AudioTrack? = null
            try {
                val block = rate / 100
                val minIn = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val minOut = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                if (minIn <= 0 || minOut <= 0) continue
                rec = AudioRecord(
                    MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, max(minIn, block * 2 * 4)
                )
                if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); continue }
                trk = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder().setSampleRate(rate)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                    )
                    .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                    .setBufferSizeInBytes(max(minOut, block * 2 * 4))
                    .setTransferMode(AudioTrack.MODE_STREAM).build()

                val engineFx = VoiceFx(rate)
                engineFx.setParams(params)
                fx = engineFx
                recorder = rec
                player = trk
                rec.startRecording()
                trk.play()
                running = true
                val r = rec
                val t = trk
                worker = Thread({ loop(r, t, engineFx, block) }, "VoiceX-Audio").also { it.start() }
                return null
            } catch (e: Exception) {
                lastError = e.message ?: lastError
                try { rec?.release() } catch (_: Exception) {}
                try { trk?.release() } catch (_: Exception) {}
            }
        }
        return lastError
    }

    private fun loop(rec: AudioRecord, trk: AudioTrack, engineFx: VoiceFx, block: Int) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val pcm = ShortArray(block)
        val f = FloatArray(block)
        while (running) {
            val n = rec.read(pcm, 0, block)
            if (n < 0) break
            if (n == 0) continue
            for (i in 0 until n) f[i] = pcm[i] / 32768f
            engineFx.process(f, n)
            for (i in 0 until n) {
                val v = (f[i] * 32767f).toInt()
                pcm[i] = (if (v > 32767) 32767 else if (v < -32768) -32768 else v).toShort()
            }
            trk.write(pcm, 0, n)
        }
        running = false
    }

    @Synchronized
    fun stop() {
        running = false
        try { worker?.join(800) } catch (_: Exception) {}
        worker = null
        try { recorder?.stop() } catch (_: Exception) {}
        try { player?.pause(); player?.flush(); player?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        recorder = null
        player = null
        fx = null
    }
}
